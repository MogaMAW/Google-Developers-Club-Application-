export interface MenuItemUnstyledClasses {
    /** Class name applied to the root element. */
    root: string;
    /** State class applied to the root `button` element if `disabled={true}`. */
    disabled: string;
    /** State class applied to the root `button` element if `focusVisible={true}`. */
    focusVisible: string;
}
export type MenuItemUnstyledClassKey = keyof MenuItemUnstyledClasses;
export declare function getMenuItemUnstyledUtilityClass(slot: string): string;
declare const menuItemUnstyledClasses: MenuItemUnstyledClasses;
export default menuItemUnstyledClasses;
