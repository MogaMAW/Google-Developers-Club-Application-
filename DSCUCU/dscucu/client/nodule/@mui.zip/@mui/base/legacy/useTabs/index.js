export { default } from './useTabs';
export * from './useTabs.types';