export { default } from './TabPanelUnstyled';
export * from './TabPanelUnstyled.types';
export { default as tabPanelUnstyledClasses } from './tabPanelUnstyledClasses';
export * from './tabPanelUnstyledClasses';