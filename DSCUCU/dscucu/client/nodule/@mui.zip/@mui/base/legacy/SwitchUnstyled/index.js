export { default } from './SwitchUnstyled';
export * from './SwitchUnstyled.types';
export { default as switchUnstyledClasses } from './switchUnstyledClasses';
export * from './switchUnstyledClasses';