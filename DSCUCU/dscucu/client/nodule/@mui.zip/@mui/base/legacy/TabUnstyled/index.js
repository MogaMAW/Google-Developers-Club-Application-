export { default } from './TabUnstyled';
export * from './TabUnstyled.types';
export { default as tabUnstyledClasses } from './tabUnstyledClasses';
export * from './tabUnstyledClasses';