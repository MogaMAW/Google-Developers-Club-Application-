export { default } from './TextareaAutosize';
export * from './TextareaAutosize.types';