export { default } from './useSwitch';
export * from './useSwitch.types';