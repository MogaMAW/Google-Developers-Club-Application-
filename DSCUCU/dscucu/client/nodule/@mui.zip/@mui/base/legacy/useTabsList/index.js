export { default } from './useTabsList';
export * from './useTabsList.types';