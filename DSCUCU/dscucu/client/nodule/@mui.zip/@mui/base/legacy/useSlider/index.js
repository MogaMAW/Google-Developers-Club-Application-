export { default } from './useSlider';
export * from './useSlider';
export * from './useSlider.types';