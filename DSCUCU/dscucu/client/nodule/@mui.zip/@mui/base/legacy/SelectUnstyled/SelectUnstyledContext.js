import * as React from 'react';
export var SelectUnstyledContext = /*#__PURE__*/React.createContext(undefined);