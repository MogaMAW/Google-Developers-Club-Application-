export function isOptionGroup(child) {
  return !!child.options;
}