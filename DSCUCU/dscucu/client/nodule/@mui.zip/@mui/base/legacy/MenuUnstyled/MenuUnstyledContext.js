import * as React from 'react';
var MenuUnstyledContext = /*#__PURE__*/React.createContext(null);
MenuUnstyledContext.displayName = 'MenuUnstyledContext';
export default MenuUnstyledContext;