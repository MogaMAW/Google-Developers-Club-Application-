import * as React from 'react';
const MenuUnstyledContext = /*#__PURE__*/React.createContext(null);
MenuUnstyledContext.displayName = 'MenuUnstyledContext';
export default MenuUnstyledContext;