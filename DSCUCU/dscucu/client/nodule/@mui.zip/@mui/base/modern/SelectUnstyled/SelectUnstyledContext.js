import * as React from 'react';
export const SelectUnstyledContext = /*#__PURE__*/React.createContext(undefined);