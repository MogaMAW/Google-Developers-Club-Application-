// eslint-disable-next-line import/prefer-default-export
export { unstable_ClassNameGenerator } from '@mui/utils';