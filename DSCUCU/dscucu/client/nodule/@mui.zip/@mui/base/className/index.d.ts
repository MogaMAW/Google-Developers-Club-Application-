export { unstable_ClassNameGenerator } from '@mui/utils';
