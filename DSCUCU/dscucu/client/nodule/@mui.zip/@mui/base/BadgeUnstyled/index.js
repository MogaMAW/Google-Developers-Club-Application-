export { default } from './BadgeUnstyled';
export * from './BadgeUnstyled.types';
export { default as badgeUnstyledClasses } from './badgeUnstyledClasses';
export * from './badgeUnstyledClasses';