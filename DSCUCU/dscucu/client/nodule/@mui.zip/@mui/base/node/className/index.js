"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "unstable_ClassNameGenerator", {
  enumerable: true,
  get: function () {
    return _utils.unstable_ClassNameGenerator;
  }
});
var _utils = require("@mui/utils");