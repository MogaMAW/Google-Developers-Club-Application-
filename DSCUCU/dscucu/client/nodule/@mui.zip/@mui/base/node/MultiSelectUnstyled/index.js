"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _MultiSelectUnstyled.default;
  }
});
var _MultiSelectUnstyled = _interopRequireDefault(require("./MultiSelectUnstyled"));