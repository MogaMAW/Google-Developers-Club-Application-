export interface ButtonUnstyledClasses {
    /** Class name applied to the root element. */
    root: string;
    /** State class applied to the root `button` element if `active={true}`. */
    active: string;
    /** State class applied to the root `button` element if `disabled={true}`. */
    disabled: string;
    /** State class applied to the root `button` element if `focusVisible={true}`. */
    focusVisible: string;
}
export type ButtonUnstyledClassKey = keyof ButtonUnstyledClasses;
export declare function getButtonUnstyledUtilityClass(slot: string): string;
declare const buttonUnstyledClasses: ButtonUnstyledClasses;
export default buttonUnstyledClasses;
