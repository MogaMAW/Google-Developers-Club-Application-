export { unstable_composeClasses as default } from '@mui/utils';
