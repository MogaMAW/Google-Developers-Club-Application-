# jss

[![Version](https://img.shields.io/npm/v/jss.svg?style=flat)](https://npmjs.org/package/jss)
[![License](https://img.shields.io/npm/l/jss.svg?style=flat)](https://github.com/cssinjs/jss/blob/master/LICENSE)
[![Downlodas](https://img.shields.io/npm/dm/jss.svg?style=flat)](https://npmjs.org/package/jss)
[![Size](https://img.shields.io/bundlephobia/minzip/jss.svg?style=flat)](https://npmjs.org/package/jss)
[![Dependencies](https://img.shields.io/david/cssinjs/jss.svg?path=packages%2Fjss&style=flat)](https://npmjs.org/package/jss)

> A lib for generating Style Sheets with JavaScript.

See our website [jss](https://cssinjs.org/setup?v=v10.10.0) for more information.

## Install

Using npm:

```sh
npm install jss
```

or using yarn:

```sh
yarn add jss
```
