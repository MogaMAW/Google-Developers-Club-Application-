﻿import Jss from '../Jss'

const createJss = (options) => new Jss(options)

/**
 * Creates a new instance of Jss.
 */
export default createJss
