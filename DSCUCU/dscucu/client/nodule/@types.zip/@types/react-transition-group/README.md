# Installation
> `npm install --save @types/react-transition-group`

# Summary
This package contains type definitions for react-transition-group (https://github.com/reactjs/react-transition-group).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-transition-group.

### Additional Details
 * Last updated: Wed, 22 Jun 2022 21:31:40 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react)
 * Global values: none

# Credits
These definitions were written by [Karol Janyst](https://github.com/LKay), [Epskampie](https://github.com/Epskampie), [Masafumi Koba](https://github.com/ybiquitous), and [Ben Grynhaus](https://github.com/bengry).
