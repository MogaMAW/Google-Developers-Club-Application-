# Installation
> `npm install --save @types/scheduler`

# Summary
This package contains type definitions for scheduler (https://reactjs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/scheduler.

### Additional Details
 * Last updated: Wed, 22 Mar 2023 23:02:44 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Nathan Bierema](https://github.com/Methuselah96), and [Sebastian Silbermann](https://github.com/eps1lon).
