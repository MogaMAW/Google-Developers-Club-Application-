/**
 * Returns the actively focused element safely.
 *
 * @param doc the document to check
 */
export default function activeElement(doc?: Document): Element | null;
