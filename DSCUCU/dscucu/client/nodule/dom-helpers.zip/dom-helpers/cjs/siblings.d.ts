/**
 * Collects all previous and next sibling elements of a given element.
 *
 * @param node the element
 */
export default function siblings(node: Element | null): Element[];
