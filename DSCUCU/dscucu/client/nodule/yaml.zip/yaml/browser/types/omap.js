const legacy = require('../dist/legacy-exports')
module.exports = legacy.omap
legacy.warnFileDeprecation(__filename)
