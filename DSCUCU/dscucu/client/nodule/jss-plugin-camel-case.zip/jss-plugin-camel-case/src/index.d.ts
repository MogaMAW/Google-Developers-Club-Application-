import {Plugin} from 'jss'

export default function jssPluginSyntaxCamelCase(): Plugin
