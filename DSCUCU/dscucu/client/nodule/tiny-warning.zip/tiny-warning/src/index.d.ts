export default function warning(condition: any, message: string): void
