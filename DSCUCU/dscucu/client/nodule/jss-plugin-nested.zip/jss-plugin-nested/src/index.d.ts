import {Plugin} from 'jss'

export default function jssPluginSyntaxNested(): Plugin
