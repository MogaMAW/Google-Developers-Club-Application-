declare module '@emotion/styled/macro' {
  import styled from '@emotion/styled'
  export * from '@emotion/styled'
  export default styled
}
