# @emotion/unitless

> An object of css properties that don't accept values with units

```jsx
import unitless from '@emotion/unitless'

unitless.flex === 1

unitless.padding === undefined
```
