module.exports = require("./data/corejs3-shipped-proposals.json");
