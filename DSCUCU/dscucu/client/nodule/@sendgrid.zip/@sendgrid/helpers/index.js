'use strict';

/**
 * Load support assets
 */
const classes = require('./classes');
const helpers = require('./helpers');

/**
 * Export
 */
module.exports = {classes, helpers};
