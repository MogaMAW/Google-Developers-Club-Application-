import RequestOptions from "@sendgrid/helpers/classes/request";

export type ClientRequest = RequestOptions;
