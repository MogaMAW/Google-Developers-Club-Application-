'use strict';

/**
 * Dependencies
 */
const Client = require('./classes/client');

//Export singleton instance
module.exports = new Client();
