import Client = require("@sendgrid/client/src/client");

export = Client;